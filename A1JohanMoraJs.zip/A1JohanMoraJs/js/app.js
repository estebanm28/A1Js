const numbers = {
    noun: ["The turkey", "Mom", "Dad", "The dog", "My teacher", "The elephant", "The cat"],
    verb: ["sat on", "ate", "danced with", "saw", "doesn't like", "kissed"],
    adjective: ["a funny", "a scary", "a goofy", "a slimy", "a barking", "a fat"],
    animal: ["goat", "monkey", "fish", "cow", "frog", "bug", "worm"],
    place: ["on the moon", "on the chair", "in my spaghetti", "in my soup", "on the grass", "in my shoes"]
};

let textToSpeak = "";

function getRandomWord(numbers) {
    return numbers[Math.floor(Math.random() * numbers.length)];
}

function speakNow(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(utterance);
}

document.querySelectorAll('.clickable').forEach(img => {
    img.addEventListener('click', (event) => {
        const word = event.target.getAttribute('data-story');
        textToSpeak += word + " ";
        document.getElementById('story-text').textContent = textToSpeak;
        speakNow(word); // Hablar inmediatamente la palabra clickeada
    });
});

document.getElementById('speak-all-button').addEventListener('click', () => {
    speakNow(textToSpeak);
});

document.getElementById('clear-selection-button').addEventListener('click', () => {
    textToSpeak = "";
    document.getElementById('story-text').textContent = "Click an image to see the story.";
});

/* Optional: Reset textToSpeak after speaking to start a new sentence */
window.speechSynthesis.addEventListener('end', () => {
    textToSpeak = "";
    document.getElementById('story-text').textContent = "Click an image to see the story.";
});
